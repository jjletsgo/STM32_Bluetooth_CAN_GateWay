/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.h
  * @brief   This file contains all the function prototypes for
  *          the usart.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __USART_H__
#define __USART_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include <stdint.h>
/* USER CODE END Includes */

extern UART_HandleTypeDef huart2;

extern UART_HandleTypeDef huart3;

/* USER CODE BEGIN Private defines */

/*============================================================================
 * Bluetooth (HC-06) 패킷 통신 정의
 *============================================================================*/
/* 패킷 프레임 정의 */
#define BT_HEADER           0xAA
#define BT_TAIL             0x55
#define BT_MAX_DATA_LEN     16      // 최대 데이터 길이
#define BT_TIMEOUT_MS       1000    // 연결 끊김 판정 타임아웃 (ms)
#define BT_PACKET_TIMEOUT_MS 50     // 패킷 수신 중 타임아웃 (ms)

/* 패킷 Type Code (GUI → Gateway) */
#define BT_TYPE_DRIVE       0x01    // 차량 구동 패킷
#define BT_TYPE_TURRET      0x02    // 터렛 제어 패킷
#define BT_TYPE_DESTRUCT    0x03    // 자폭 명령
#define BT_TYPE_MODE        0x04    // 모드 전환
#define BT_TYPE_LASER       0x05    // 레이저 ON/OFF

/* 패킷 Type Code (Gateway → GUI) */
#define BT_TYPE_STATUS      0x81    // 시스템 상태 패킷
#define BT_TYPE_DRONE       0x82    // 드론 발견 여부
#define BT_TYPE_OBSTACLE    0x83    // 장애물 알림 패킷

/* 수신 상태 머신 */
typedef enum {
    BT_STATE_WAIT_HEADER,
    BT_STATE_WAIT_TYPE,
    BT_STATE_WAIT_LENGTH,
    BT_STATE_WAIT_DATA,
    BT_STATE_WAIT_CHECKSUM,
    BT_STATE_WAIT_TAIL
} BT_RxState_t;

/* 블루투스 연결 상태 */
typedef enum {
    BT_DISCONNECTED,
    BT_CONNECTED
} BT_ConnState_t;

/* 수신된 패킷 구조체 */
typedef struct {
    uint8_t type;
    uint8_t length;
    uint8_t data[BT_MAX_DATA_LEN];
    uint8_t checksum;
    uint8_t valid;  // 패킷 유효 여부 (수신 완료 시 1)
} BT_Packet_t;

/* 차량 구동 패킷 데이터 (BT-TX-001) */
typedef struct {
    uint8_t leftSpeed;      // 0-255
    uint8_t rightSpeed;     // 0-255
    uint8_t leftDir;        // 0/1
    uint8_t rightDir;       // 0/1
    uint8_t brake;          // 0/1
} BT_DriveData_t;

/* 터렛 제어 패킷 데이터 (BT-TX-002) */
typedef struct {
    int16_t xMovement;      // X좌표 이동량 (signed)
    int16_t yMovement;      // Y좌표 이동량 (signed)
} BT_TurretData_t;

/* 외부 변수 선언 */
extern volatile BT_ConnState_t bt_connection_state;
extern volatile BT_Packet_t bt_rx_packet;
extern volatile uint8_t bt_new_packet_flag;

/* USER CODE END Private defines */

void MX_USART2_UART_Init(void);
void MX_USART3_UART_Init(void);

/* USER CODE BEGIN Prototypes */
/*============================================================================
 * Bluetooth (HC-06) 통신 함수
 *============================================================================*/
void BT_Init(void);                         // 블루투스 모듈 초기화
void BT_RxHandler(uint8_t rxByte);          // UART3 인터럽트에서 호출 (1바이트 수신 처리)
void BT_ProcessPacket(void);                // 수신된 패킷 처리 (main loop에서 호출)
void BT_CheckConnection(void);              // 연결 상태 확인 (1ms 타이머에서 호출)
void BT_PrintPacket(void);                  // 디버그용 패킷 출력
void BT_SendStatus(uint8_t state);          // GUI로 상태 전송
void BT_SendDrone(uint8_t state);           // 드론 발견 여부 전송
void BT_SendObstacle(uint8_t distance_cm, uint8_t direction); // 장애물 알림 전송

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __USART_H__ */

