/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    can.h
  * @brief   This file contains all the function prototypes for
  *          the can.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __CAN_H__
#define __CAN_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

extern CAN_HandleTypeDef hcan1;

/* USER CODE BEGIN Private defines */
// CAN 관련 변수들을 main에서 쓸 수 있도록 extern으로 설정
extern uint8_t				can1_rx0_flag;
extern CAN_FilterTypeDef 	canFilter;
extern CAN_RxHeaderTypeDef 	canRxHeader;
extern CAN_TxHeaderTypeDef 	canTxHeader;
extern uint32_t 			TxMailBox;
extern uint8_t 				can1Rx0Data[8]; //CAN 수신 버퍼
extern uint8_t 				can1Tx0Data[8]; //CAN 송신 버퍼
/* USER CODE END Private defines */

void MX_CAN1_Init(void);

/* USER CODE BEGIN Prototypes */
void MX_CAN1_Filter_List16_ICD(void);
void CAN_HandleRxMessage(void);
void CAN_UpdateDriveCommand(uint8_t leftSpeed, uint8_t rightSpeed, uint8_t leftDir, uint8_t rightDir, uint8_t brake);
void CAN_UpdateTurretManual(int16_t x, int16_t y);
void CAN_UpdateTurretAuto(int16_t x, int16_t y);
void CAN_SendDestruct(uint8_t command);
void CAN_SendModeSwitch(uint8_t command);
void CAN_SendLaserToggle(uint8_t command);
void CAN_SendPeriodic30ms(void);
uint8_t CAN_BuildStatusByte(void);
uint8_t CAN_GetDroneState(void);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif

#endif /* __CAN_H__ */

