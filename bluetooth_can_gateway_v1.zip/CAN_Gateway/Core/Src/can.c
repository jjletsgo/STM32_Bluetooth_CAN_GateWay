/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    can.c
  * @brief   This file provides code for the configuration
  *          of the CAN instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "can.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>

/* USER CODE BEGIN 0 */
/*
 * 헤더에서 만든 extern 변수들을 여기서 실제로 정의함
 * */
uint8_t 				can1_rx0_flag = 0; //can 수신 데이터 도착시 ISR에서 해당 플래그를 1로 설정, main문에서 수신 처리
CAN_FilterTypeDef 		canFilter; //Filter 구조체 변수 선언
CAN_RxHeaderTypeDef 	canRxHeader; //수신 헤더 구조체 변수 선언
CAN_TxHeaderTypeDef 	canTxHeader; //송신 헤더 구조체 변수 선언
uint32_t 				TxMailBox; //CAN 송신에 사용할 메일 박스 (cpu의 송신 메시지 설정을 위한 인터페이스)
uint8_t 				can1Rx0Data[8]; //수신 데이터를 저장하는 버퍼
uint8_t 				can1Tx0Data[8]; //송신 데이터를 저장하는 버퍼

//차량 구동 명령 구조체
typedef struct {
	uint8_t leftSpeed;
	uint8_t rightSpeed;
	uint8_t leftDir;
	uint8_t rightDir;
	uint8_t brake;
} GatewayDriveCmd_t;

//터렛 제어 명령 구조체
typedef struct {
	int16_t x;//x좌표
	int16_t y;//y좌표
} GatewayTurretCmd_t;

static volatile GatewayDriveCmd_t drive_cmd = {0, }; // 구조체 전체를 0으로 초기화
static volatile GatewayTurretCmd_t turret_manual_cmd = {0, }; // 구조체 전체를 0으로 초기화
static volatile GatewayTurretCmd_t turret_auto_cmd = {0, }; // 구조체 전체를 0으로 초기화

//각 하트비트(0x701, 0x702, 0x703)를 마지막으로 수신한 시각(HAL_GetTick() 값, ms 단위)을 저장
static volatile uint32_t hb_drive_tick = 0;
static volatile uint32_t hb_gimbal_tick = 0;
static volatile uint32_t hb_jetson_tick = 0;
//각 하트비트 페이로드의 상태 코드(Byte0)를 저장합니다. 관례대로 0이면 정상, 1이면 비정상으로 판단
static volatile uint8_t  hb_drive_code = 1;
static volatile uint8_t  hb_gimbal_code = 1;
static volatile uint8_t  hb_jetson_code = 1;

//드론 감지(0x121 수신) 플래그가 1로 설정된 시점의 tick 값을 기록하는 변수
static volatile uint32_t drone_detect_tick = 0;
//마지막으로 받은 드론 감지 플래그(Byte0)를 저장합니다. 1이면 감지, 0이면 미감지.
static volatile uint8_t  drone_detect_state = 0;

uint8_t CAN_GetDroneState(void)
{
	//now에 현재 Tick 값 저장
	uint32_t now = HAL_GetTick();
	//드론이 300ms이내에 재감지되면 실행
	if (drone_detect_state && (drone_detect_tick != 0) && (now - drone_detect_tick < 300)) {
		return 1;
	}
	return 0;
}

//인자로 메시지 ID, DLC, 데이터 버퍼 주소 보내주면 CAN 송신 스케줄링을 요청하는 함수
static HAL_StatusTypeDef CAN_SendStdFrame(uint16_t std_id, uint8_t dlc, uint8_t *payload)
{
	//인자로 받은 대로 송신 헤더 설정
	canTxHeader.StdId = std_id;
	canTxHeader.RTR   = CAN_RTR_DATA;
	canTxHeader.IDE   = CAN_ID_STD;
	canTxHeader.DLC   = dlc;

	//3qjs wotleh
	for (uint8_t retry = 0; retry < 3; retry++)
	{
		//첫 번째 송신 메일 박스에 메시지 등록 (can설정 구조체, can헤더, can 데이터, 메일박스 주소를 넘겨줌) 하고
		// 송신 스케줄링을 요청함
		if (HAL_CAN_AddTxMessage(&hcan1, &canTxHeader, payload, &TxMailBox) == HAL_OK)
		{
			//송신 스케줄링 요청된 CAN 프레임을 UART로 출력
			printf("[CAN TX] %03X [%d] %02X %02X %02X %02X %02X %02X %02X %02X\r\n",
				   std_id, dlc,
				   payload[0], payload[1], payload[2], payload[3],
				   payload[4], payload[5], payload[6], payload[7]);
			return HAL_OK; //정상 상태 반환
		}
		//정상적으로 송신 스케줄링 요청 X 시 재시도
	}

	//3번 모두 실패한경우 에러 로그남김
	printf("[CAN TX][ERR] %03X\r\n", std_id);
	//에러 상태 반환
	return HAL_ERROR;
}
/* USER CODE END 0 */

CAN_HandleTypeDef hcan1;

/* CAN1 init function */
void MX_CAN1_Init(void) //CAN1설정하는 MX에서 GENERATE 해주는 함수
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 4;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_15TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_5TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  /* USER CODE END CAN1_Init 2 */

}

void HAL_CAN_MspInit(CAN_HandleTypeDef* canHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspInit 0 */

  /* USER CODE END CAN1_MspInit 0 */
    /* CAN1 clock enable */
    __HAL_RCC_CAN1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF9_CAN1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* CAN1 interrupt Init */
    HAL_NVIC_SetPriority(CAN1_RX0_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(CAN1_RX0_IRQn);
  /* USER CODE BEGIN CAN1_MspInit 1 */

  /* USER CODE END CAN1_MspInit 1 */
  }
}

void HAL_CAN_MspDeInit(CAN_HandleTypeDef* canHandle)
{

  if(canHandle->Instance==CAN1)
  {
  /* USER CODE BEGIN CAN1_MspDeInit 0 */

  /* USER CODE END CAN1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_CAN1_CLK_DISABLE();

    /**CAN1 GPIO Configuration
    PA11     ------> CAN1_RX
    PA12     ------> CAN1_TX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_11|GPIO_PIN_12);

    /* CAN1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(CAN1_RX0_IRQn);
  /* USER CODE BEGIN CAN1_MspDeInit 1 */

  /* USER CODE END CAN1_MspDeInit 1 */
  }
}

/*
 * 공부용 코드. 참고용임.----------------------------------------------------------------------
 * */
/* USER CODE BEGIN 1 */
void MX_CAN1_Filter_list16(void)
{
	/*
	 * RTR,IDE,EXID가 5비트 차지하므로 왼쪽으로 5번 sfhit해준다. (표준CAN에서 ID는 11비트이니 5번 SHIFT해도 값을 손실X)
	 *
	 *  */
	//uint32_t addr32=0x106;

	canFilter.FilterIdHigh = 0X106<<5;//addr32<<5;
	canFilter.FilterIdLow = 0;
	canFilter.FilterMaskIdHigh=0;
	canFilter.FilterMaskIdLow=0;
	canFilter.FilterMode = CAN_FILTERMODE_IDLIST; //리스트모드로 설정
	canFilter.FilterScale = CAN_FILTERSCALE_16BIT; //필터 뱅크의 스케일을 16비트로 설정. 필터 뱅크 = 16비트*4
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0; //2개의 FIFO중, FIFO0으로 수신
	/*필터 뱅크 0을 사용(Bank를 최대 14개까지 설정가능하다고한다.
	 * Reference manual에는 필터 뱅크가 can1,can2가 전체 28개를 공유해서 쓴다고 나와있는데
	 * 왜 Hal_Driver의 주석상으로는 최대 14개인지 알아볼필요있을듯*/
	canFilter.FilterBank = 0;
	canFilter.FilterActivation = ENABLE; // 필터를 활성화한다.

	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING); //CAN RX 인터럽트를 Enable
}

/*
 * 32bits LIST Mode로 설정
 * */
void MX_CAN1_Filter_list32(void)
{
	/*
	 * 확장 can의 경우 id를 총 29비트 사용 가능하다.->id는 32비트중 하위 29비트이다.
	 * 0x12345678은 상위 3비트가 0이라 현재 28개의 비트를 사용 중이다.
	 * 왼쪽으로 3번 shift 후 분리하면 id기준으로 상위 16비트, 하위 13비트 분리가 가능하다.
	 * 왼쪽으로 3번 shift 하고 상위16비트, 하위 13비트로 분리한다. */
	uint32_t addr32 = 0x12345678;

	canFilter.FilterIdHigh = (addr32<<3) >> 16; //addr32의 상위 16비트를 FilterIdHigh에 저장
	/*
	 * addr32의 하위 16비트를 FilterIdLow에 저장하고,
	 * 확장 CAN에 대한 필터링이므로, FilterIdLow의 2번 비트(수신된 메시지의 IDE와 비교되는 비트)를 1로 set*/
	canFilter.FilterIdLow = ((addr32<<3) & 0xffff) | 0x04;
	canFilter.FilterMaskIdHigh=0;
	canFilter.FilterMaskIdLow=0;
	canFilter.FilterMode = CAN_FILTERMODE_IDLIST; //리스트모드로 설정
	canFilter.FilterScale = CAN_FILTERSCALE_32BIT; //필터 뱅크의 스케일을 32비트로 설정.
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0; //2개의 FIFO중, FIFO0으로 수신
	canFilter.FilterBank = 0;
	canFilter.FilterActivation = ENABLE; // 필터를 활성화한다.

	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING); //CAN RX 인터럽트를 Enable
}

/*
 * 16비트 마스크모드로 설정
 * */
void MX_CAN1_Filter_mask16(void)
{
	/*
	 * 필터 id     = 0x106=0b00100000110
	 * 필터 mask   = 0x7f0=0b11111110000
	 * 이므로, 0b0010000xxxx=0x100 ~ 0x10F가 통과할 수 있다
	 * 즉, 수신 가능한 id의 범위는 0x100 ~ 0x10F 이다.
	 * */
	uint32_t addr32 = 0x106; //필터 id
	uint32_t mask32 = 0x7f0; //필터 mask


	canFilter.FilterIdHigh = addr32<<5;
	canFilter.FilterIdLow = 0;
	/*
	 *
	 * 16bits Mask Mode일 때에는 MaskIdLow 을 MaskIdHigh 값과 동일한 값으로 설정해야 한다.
	 * MaskIdLow 값을 0로 설정하면 Mask 값이 0가 되어 모든 메시지를 수신하게 되버린다.
	 * 그래서 둘 중 1개의 mask만 쓰는 경우, 안쓰는 mask의 id도 사용하는 mask의 id와 동일하게 설정해줘야한다.
	 * */
	canFilter.FilterMaskIdHigh  =  mask32<<5;
	canFilter.FilterMaskIdLow   =  mask32<<5;
	canFilter.FilterMode = CAN_FILTERMODE_IDMASK; //mask모드로 설정
	canFilter.FilterScale = CAN_FILTERSCALE_16BIT; //필터 뱅크의 스케일을 16비트로 설정.
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0; //2개의 FIFO중, FIFO0으로 수신
	canFilter.FilterBank = 0;
	canFilter.FilterActivation = ENABLE; // 필터를 활성화한다.

	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING); //CAN RX 인터럽트를 Enable
}

/*
 * 32비트 마스크모드 설정
 * */

void MX_CAN1_Filter_mask32(void)
{
	/*
	 * 필터 id     = 0x12345678
	 * 필터 mask   = 0x1ffffff0 = 0x 1 1111 1111 1111 1111 1111 1111 0000
	 * 이므로, 0x12345670~0x1234567F 의 id를 가지는 메시지를 수신할 수 있다.
	 * */
	uint32_t addr32 = 0x12345678; //필터 id
	uint32_t mask32 = 0x1ffffff0; //필터 mask


	canFilter.FilterIdHigh = (addr32<<3) >> 16; //id기준 상위 16비트를 저장
	/*
	 * id기준 하위 13비트 저장 및 확장 can을 수신하기위하여 2번비트를 1로 set
	 * */
	canFilter.FilterIdLow = ((addr32<<3) & 0xffff) | 0x04;
	canFilter.FilterMaskIdHigh  =  (mask32<<3) >> 16;
	canFilter.FilterMaskIdLow   =  ((mask32<<3) & 0xffff) | 0x04;
	canFilter.FilterMode = CAN_FILTERMODE_IDMASK; //mask모드로 설정
	canFilter.FilterScale = CAN_FILTERSCALE_32BIT; //필터 뱅크의 스케일을 32비트로 설정.
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0; //2개의 FIFO중, FIFO0으로 수신
	canFilter.FilterBank = 0;
	canFilter.FilterActivation = ENABLE; // 필터를 활성화한다.

	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING); //CAN RX 인터럽트를 Enable
}

/*
 * 16비트 리스트 모드로 2개의 id수신하는 하도록 필터 설정하는 함수
 * 0x106, 0x110 ID 수신 가능
 * */
void MX_CAN1_Filter_list16_ex(void)
{
	//bank0
	uint32_t addr32_0=0x106;//첫 번째 id

	canFilter.FilterIdHigh = addr32_0<<5;
	canFilter.FilterIdLow = 0;
	canFilter.FilterMaskIdHigh=0;
	canFilter.FilterMaskIdLow=0;
	canFilter.FilterMode = CAN_FILTERMODE_IDLIST;
	canFilter.FilterScale = CAN_FILTERSCALE_16BIT;
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0;

	canFilter.FilterBank = 0;
	canFilter.FilterActivation = ENABLE; // 필터를 활성화한다.

	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write

	//bank1
	uint32_t addr32_1=0x110;//두 번째 id

	canFilter.FilterIdHigh = addr32_1<<5;
	canFilter.FilterBank = 1;
	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //설정된 Filter 값을 레지스터에 Write
	//CAN FIFO0 수신 인터럽트를 Enable
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);
}

/*
 * 공부용 코드. 참고용임.----------------------------------------------------------------------
 * */
/*
 * ICD 맞춤 16비트 리스트 필터
 * RX ID: 0x011, 0x121, 0x701, 0x702, 0x703
 */
void MX_CAN1_Filter_List16_ICD(void)
{
	//필터뱅크를 LIST모드로 설정
	canFilter.FilterMode = CAN_FILTERMODE_IDLIST;
	// 2개의 32비트 필터 레지스터 크기를 각각 16비트로 설정 -> LIST모드 이므로 총 4개의 16비트 필터 생성
	canFilter.FilterScale = CAN_FILTERSCALE_16BIT;
	// 2개의 수신 FIFO 중, FIFO0 사용
	canFilter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	// 필터 활성화
	canFilter.FilterActivation = ENABLE;

	// Bank0 : 0x011, 0x121, 0x701, 0x702 <---ICD상으로 수신한다고 정의한 메시지들
	canFilter.FilterBank = 0; //0~27번의 필터뱅크 중 , 0번 필터 뱅크를 사용하겠다고 설정
	canFilter.FilterIdHigh      = (0x011 << 5); //첫 번째 ID 필터
	canFilter.FilterIdLow       = (0x121 << 5); //두 번째 ID 필터
	canFilter.FilterMaskIdHigh  = (0x701 << 5); //세 번째 ID 필터
	canFilter.FilterMaskIdLow   = (0x702 << 5); //네 번째 ID 필터
	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //필터 설정

	// Bank1 : 0x703, dummy(0x7FF)
	canFilter.FilterBank = 1; //0~27번의 필터뱅크 중 , 1번 필터 뱅크를 사용하겠다고 설정
	canFilter.FilterIdHigh      = (0x703 << 5); //첫 번째 ID 필터
	/*
	 * 이 아래로는 그냥 더미로 필터 만들어둠. 어떤 ID로 설정하든, 실제 ICD상에서 사용하는 메시지 ID만 아니면 상관 X
	 * */
	canFilter.FilterIdLow       = (0x7FF << 5);
	canFilter.FilterMaskIdHigh  = (0x7FF << 5);
	canFilter.FilterMaskIdLow   = (0x7FF << 5);
	HAL_CAN_ConfigFilter(&hcan1, &canFilter); //필터 설정
	//CAN FIFO0 수신 인터럽트를 Enable
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);
}

/* 사용자 로직 */
// 인자로 전달 받은 데이터를 기반으로 차량 구동 명령 구조체를 업데이트함
void CAN_UpdateDriveCommand(uint8_t leftSpeed, uint8_t rightSpeed, uint8_t leftDir, uint8_t rightDir, uint8_t brake)
{
	/*변수를 Atomic하게 update하기위한 인터럽트 일시적 비활성화
	 *블루투스 수신 isr에서 해당 함수를 호출하는데, 이와 중첩되게 타이머 인터럽트가 해당 drive_cmd 구조체를 읽을 수 있음
	 *그렇게되면 타이머 인터럽트 context에서 drive_cmd값을 읽을 때 엉터리 값을 읽게될 수 있음
	 *(블루투스 수신 ISR Context에서 해당 drive_cmd 구조체를 수정하던 도중에 멈추고 타이머 인터럽트가 실행됐으므로)
	 *따라서 이를 방지하기위해, atomic 하게 update하도록 인터럽트를 일시적으로 비활성화함
	 */
	__disable_irq();
	drive_cmd.leftSpeed  = leftSpeed;
	drive_cmd.rightSpeed = rightSpeed;
	drive_cmd.leftDir    = leftDir;
	drive_cmd.rightDir   = rightDir;
	drive_cmd.brake      = brake;
	__enable_irq();
}

// 인자로 전달 받은 데이터를 기반으로 터렛 구동 명령 구조체를 atomic하게 업데이트함
void CAN_UpdateTurretManual(int16_t x, int16_t y)
{
	__disable_irq();
	turret_manual_cmd.x = x;
	turret_manual_cmd.y = y;
	__enable_irq();
}

/*
 * 아래 함수는 없어도될듯?
 * */
void CAN_UpdateTurretAuto(int16_t x, int16_t y)
{
	__disable_irq();
	turret_auto_cmd.x = x;
	turret_auto_cmd.y = y;
	__enable_irq();
}

//현재 차량 구동 명령 구조체를 기반으로 송신 프레임 생성을 위한 버퍼를 update함
static void CAN_BuildDriveFrame(uint8_t *frame)
{
	GatewayDriveCmd_t copy;
	// 차량 구동 명령 구조체 drive_cmd를 atomic하게 copy함
	__disable_irq();
	copy = drive_cmd;
	__enable_irq();

	//현재 차량 구동 명령 구조체를 기반으로 송신 프레임 생성을 위한 버퍼를 update함
	frame[0] = copy.leftSpeed;
	frame[1] = copy.rightSpeed;
	frame[2] = copy.leftDir;
	frame[3] = copy.rightDir;
	frame[4] = copy.brake;
	frame[5] = 0;
	frame[6] = 0;
	frame[7] = 0;
}

//현재 터렛 구동 명령 구조체를 기반으로 송신 프레임 생성을 위한 버퍼를 update함
static void CAN_BuildTurretFrame(const GatewayTurretCmd_t *src, uint8_t *frame)
{
	frame[0] = (uint8_t)((src->x >> 8) & 0xFF);
	frame[1] = (uint8_t)(src->x & 0xFF);
	frame[2] = (uint8_t)((src->y >> 8) & 0xFF);
	frame[3] = (uint8_t)(src->y & 0xFF);
	frame[4] = 0;
	frame[5] = 0;
	frame[6] = 0;
	frame[7] = 0;
}

//30ms주기로  차량 구동 프레임, 터렛 구동 프레임을 update해서 -> 실제로 can 송신 스케줄링을 요청하는 함수
void CAN_SendPeriodic30ms(void)
{
	uint8_t frame[8];
	GatewayTurretCmd_t manual_copy;

	// 0x100 차량 구동
	CAN_BuildDriveFrame(frame); //프레임 생성
	CAN_SendStdFrame(0x100, 8, frame); //실제로 can 송신 스케줄링을 요청

	__disable_irq();
	manual_copy = turret_manual_cmd;
	__enable_irq();

	// 0x101 터렛 수동
	CAN_BuildTurretFrame(&manual_copy, frame); //프레임 생성
	CAN_SendStdFrame(0x101, 8, frame); //실제로 can 송신 스케줄링을 요청
}

//자폭 명령 프레임 생성 및 can 송신 스케줄링 요청
void CAN_SendDestruct(uint8_t command)
{
	uint8_t frame[8] = {0,};
	frame[0] = command ? 1 : 0;
	CAN_SendStdFrame(0x010, 8, frame);
}

//모드 변경 프레임 생성 및 can 송신 스케줄링 요청
void CAN_SendModeSwitch(uint8_t command)
{
	uint8_t frame[8] = {0,};
	frame[0] = command ? 1 : 0;
	CAN_SendStdFrame(0x111, 8, frame);
}

//레이저 ON/OFF 프레임 생성 및 can 송신 스케줄링 요청
void CAN_SendLaserToggle(uint8_t command)
{
	uint8_t frame[8] = {0,};
	frame[0] = command ? 1 : 0;
	CAN_SendStdFrame(0x120, 8, frame);
}

uint8_t CAN_BuildStatusByte(void)
{
	/* 상태 비트 (1=정상)
	 * bit3: Gateway (자체) 항상 1
	 * bit2: Drive heartbeat 정상(<=1s, code==0)
	 * bit1: Jetson heartbeat 정상(<=1s, code==0)
	 * bit0: Turret/Gimbal heartbeat 정상(<=1s, code==0)
	 */
	uint32_t now = HAL_GetTick(); //현재 tick을 지역 변수 now에 저장
	uint8_t state = 0; //현재 상태를 0으로 설정

	// Gateway는 로컬 MCU이므로 항상 1
	state |= (1 << 3); //state의 3번 비트를 1로 set
	if ((hb_drive_tick != 0) && (now - hb_drive_tick <= 600) && (hb_drive_code == 0))
		state |= (1 << 2); //state의 2번 비트를 1로 set

	if ((hb_jetson_tick != 0) && (now - hb_jetson_tick <= 600) && (hb_jetson_code == 0))
		state |= (1 << 1); //state의 1번 비트를 1로 set

	if ((hb_gimbal_tick != 0) && (now - hb_gimbal_tick <= 600) && (hb_gimbal_code == 0))
		state |= (1 << 0); //state의 0번 비트를 1로 set

	return state;
}

//수신 메시지 처리 함수
void CAN_HandleRxMessage(void)
{
	if (can1_rx0_flag == 0) return; //수신 데이터 도착 x인 경우

	CAN_RxHeaderTypeDef header; //can 수신 헤더 생성
	uint8_t data[8];

	__disable_irq(); //atomic 구간
	can1_rx0_flag = 0; //can 수신 인터럽트 플래그를 atomic하게 0으로 설정
	header = canRxHeader; //CAN수신 헤더를 지역 변수 header로 atomci하게 복사
	// CAN 수신 ISR에서 채워 둔 수신 데이터를 저장하는 전역 버퍼 can1Rx0Data(8바이트)를 로컬 배열 data로 한 번에 복사
	memcpy(data, can1Rx0Data, sizeof(data));
	__enable_irq(); //atomic 구간

	if (header.IDE != CAN_ID_STD) //표준 CAN이 아니면
	{
		printf("[CAN RX] EXT ID %08lX ignored\r\n", header.ExtId);
		return; //반환
	}

	//수신 헤더, 수신 데이터를 printf로 출력(사실상 uart2로 송신하는 것임)
	printf("[CAN RX] %03lX [%lu] %02X %02X %02X %02X %02X %02X %02X %02X\r\n",
		   header.StdId, (unsigned long)header.DLC,
		   data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]);

	switch (header.StdId) //CAN의 id값에 따른 분기 처리
	{
	case 0x011: // 장애물 알림
		BT_SendObstacle(data[1], data[2]); //블루투스로 장애물 정보 송신
		break;

	case 0x121: // 드론 감지
		drone_detect_state = data[0] ? 1 : 0;
		drone_detect_tick = drone_detect_state ? HAL_GetTick() : 0;
		//아래 코드 수정해야할듯. 주변 제어기 상태는 30ms주기로 보내는게 나을듯싶다
		BT_SendStatus(CAN_BuildStatusByte());
		//드론 감지 했다고 블루투스로 전송
		BT_SendDrone(CAN_GetDroneState());
		break;

	//drive 하트비트 메시지 처리
	case 0x701: // Drive heartbeat
		hb_drive_code = data[0];
		hb_drive_tick = HAL_GetTick();
		break;
	//gimbal(터렛) 하트비트 메시지 처리
	case 0x702: // Gimbal heartbeat
		hb_gimbal_code = data[0];
		hb_gimbal_tick = HAL_GetTick();
		break;
	//Jetson Orin Nano 하트비트 메시지 처리
	case 0x703: // Jetson heartbeat
		hb_jetson_code = data[0];
		hb_jetson_tick = HAL_GetTick();
		break;

	default:
		break;
	}
}
/* USER CODE END 1 */
