/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "usart.h"

/* USER CODE BEGIN 0 */
#include "can.h"
#include <stdio.h>
#include <string.h>

/*============================================================================
 * Bluetooth (HC-06) 패킷 통신 변수
 *============================================================================*/
/* 상태 머신 변수 */
static BT_RxState_t bt_rx_state = BT_STATE_WAIT_HEADER;
static uint8_t bt_rx_buffer[BT_MAX_DATA_LEN + 6];  // Header + Type + Length + Data + Checksum + Tail
static uint8_t bt_rx_index = 0;
static uint8_t bt_expected_length = 0;
static uint8_t bt_calc_checksum = 0;

/* 연결 타임아웃 변수 (HAL_GetTick() 기반) */
static volatile uint32_t bt_last_rx_time = 0;
static volatile uint32_t bt_packet_start_time = 0;  // 패킷 수신 시작 시간

/* 외부에서 접근 가능한 변수 */
volatile BT_ConnState_t bt_connection_state = BT_DISCONNECTED;
volatile BT_Packet_t bt_rx_packet;
volatile uint8_t bt_new_packet_flag = 0;

static uint8_t BT_CalcChecksum(const uint8_t *buf, uint8_t len)
{
    uint8_t cs = 0;
    for (uint8_t i = 0; i < len; i++) cs ^= buf[i];
    return cs;
}

static void BT_SendPacket(uint8_t type, uint8_t length, const uint8_t *data)
{
    uint8_t frame[BT_MAX_DATA_LEN + 5]; // Header, Type, Len, Data, Cksum, Tail
    uint8_t idx = 0;

    frame[idx++] = BT_HEADER;
    frame[idx++] = type;
    frame[idx++] = length;
    for (uint8_t i = 0; i < length; i++)
    {
        frame[idx++] = data[i];
    }
    {
        uint8_t cs = BT_CalcChecksum(frame, idx);
        frame[idx++] = cs;
    }
    frame[idx++] = BT_TAIL;

    HAL_UART_Transmit(&huart3, frame, idx, 50);
    printf("[BT TX] type=0x%02X len=%d\r\n", type, length);
}

/*============================================================================
 * Bluetooth 초기화
 *============================================================================*/
void BT_Init(void)
{
    bt_rx_state = BT_STATE_WAIT_HEADER;
    bt_rx_index = 0;
    bt_expected_length = 0;
    bt_calc_checksum = 0;
    bt_connection_state = BT_DISCONNECTED;
    bt_new_packet_flag = 0;
    bt_last_rx_time = HAL_GetTick();
    bt_packet_start_time = HAL_GetTick();
    memset((void*)&bt_rx_packet, 0, sizeof(BT_Packet_t));

    printf("[BT] Bluetooth module initialized.\r\n");
}

/*============================================================================
 * Bluetooth 1바이트 수신 처리 (UART3 인터럽트에서 호출)
 * ★ 개선: 동기화 복구 기능 추가
 *============================================================================*/
void BT_RxHandler(uint8_t rxByte)
{
    // 타임아웃 리셋 (HAL_GetTick() 사용)
    bt_last_rx_time = HAL_GetTick();

    // 연결 상태 업데이트
    if (bt_connection_state == BT_DISCONNECTED)
    {
        bt_connection_state = BT_CONNECTED;
        printf("[BT] Connected!\r\n");
    }

    // ★★★ 핵심 개선: 어떤 상태에서든 0xAA가 오면 새 패킷 시작으로 처리 ★★★
    // 동기화가 깨졌을 때 빠르게 복구
    if (rxByte == BT_HEADER && bt_rx_state != BT_STATE_WAIT_HEADER)
    {
        // 새 패킷 시작 - 이전 불완전 패킷 폐기
        bt_rx_index = 0;
        bt_rx_buffer[bt_rx_index++] = rxByte;
        bt_calc_checksum = rxByte;
        bt_packet_start_time = HAL_GetTick();
        bt_rx_state = BT_STATE_WAIT_TYPE;
        return;  // 여기서 처리 완료
    }

    switch (bt_rx_state)
    {
        case BT_STATE_WAIT_HEADER:
            if (rxByte == BT_HEADER)
            {
                bt_rx_index = 0;
                bt_rx_buffer[bt_rx_index++] = rxByte;
                bt_calc_checksum = rxByte;  // Checksum 시작
                bt_packet_start_time = HAL_GetTick();  // 패킷 시작 시간 기록
                bt_rx_state = BT_STATE_WAIT_TYPE;
            }
            // 다른 바이트는 무시 (헤더 대기 중)
            break;

        case BT_STATE_WAIT_TYPE:
            bt_rx_buffer[bt_rx_index++] = rxByte;
            bt_calc_checksum ^= rxByte;
            bt_rx_state = BT_STATE_WAIT_LENGTH;
            break;

        case BT_STATE_WAIT_LENGTH:
            bt_rx_buffer[bt_rx_index++] = rxByte;
            bt_calc_checksum ^= rxByte;
            bt_expected_length = rxByte;

            // ★ 개선: Length 유효 범위 체크 (1~16)
            if (bt_expected_length == 0 || bt_expected_length > BT_MAX_DATA_LEN)
            {
                // 비정상 길이 - 상태 리셋 (에러 로그 간소화)
                bt_rx_state = BT_STATE_WAIT_HEADER;
            }
            else
            {
                bt_rx_state = BT_STATE_WAIT_DATA;
            }
            break;

        case BT_STATE_WAIT_DATA:
            bt_rx_buffer[bt_rx_index++] = rxByte;
            bt_calc_checksum ^= rxByte;

            // Header(1) + Type(1) + Length(1) + Data(expected_length) = 3 + expected_length
            if (bt_rx_index >= (3 + bt_expected_length))
            {
                bt_rx_state = BT_STATE_WAIT_CHECKSUM;
            }
            break;

        case BT_STATE_WAIT_CHECKSUM:
            bt_rx_buffer[bt_rx_index++] = rxByte;

            if (bt_calc_checksum == rxByte)
            {
                bt_rx_state = BT_STATE_WAIT_TAIL;
            }
            else
            {
                // 체크섬 실패 - 상태 리셋
                bt_rx_state = BT_STATE_WAIT_HEADER;
            }
            break;

        case BT_STATE_WAIT_TAIL:
            if (rxByte == BT_TAIL)
            {
                bt_rx_buffer[bt_rx_index++] = rxByte;

                // 패킷 완성 - 데이터 복사
                bt_rx_packet.type = bt_rx_buffer[1];
                bt_rx_packet.length = bt_rx_buffer[2];
                memcpy((void*)bt_rx_packet.data, &bt_rx_buffer[3], bt_expected_length);
                bt_rx_packet.checksum = bt_rx_buffer[3 + bt_expected_length];
                bt_rx_packet.valid = 1;
                bt_new_packet_flag = 1;
            }
            // Tail 실패해도 그냥 다음 패킷 대기
            bt_rx_state = BT_STATE_WAIT_HEADER;
            break;

        default:
            bt_rx_state = BT_STATE_WAIT_HEADER;
            break;
    }
}

/*============================================================================
 * Bluetooth 연결 상태 확인 (main loop 또는 타이머에서 호출)
 * ★ 개선: 패킷 수신 중 타임아웃 체크 추가
 *============================================================================*/
void BT_CheckConnection(void)
{
    uint32_t current_tick = HAL_GetTick();

    // 연결 타임아웃 체크 (1000ms)
    if (bt_connection_state == BT_CONNECTED)
    {
        if ((current_tick - bt_last_rx_time) > BT_TIMEOUT_MS)
        {
            bt_connection_state = BT_DISCONNECTED;
            bt_rx_state = BT_STATE_WAIT_HEADER;  // 상태 리셋
            printf("[BT] Disconnected (timeout)\r\n");
        }
    }

    // ★ 패킷 수신 중 타임아웃 체크 (50ms)
    // 패킷 수신 시작 후 일정 시간 내 완료되지 않으면 상태 리셋
    if (bt_rx_state != BT_STATE_WAIT_HEADER)
    {
        if ((current_tick - bt_packet_start_time) > BT_PACKET_TIMEOUT_MS)
        {
            bt_rx_state = BT_STATE_WAIT_HEADER;  // 불완전 패킷 폐기
        }
    }
}

/*============================================================================
 * 수신된 패킷 디버그 출력 (로컬 복사본 사용)
 *============================================================================*/
static void BT_PrintPacketData(BT_Packet_t *pkt)
{
    uint8_t i;

    printf("[BT] RX Packet - Type: 0x%02X, Len: %d, Data: ",
           pkt->type, pkt->length);

    for (i = 0; i < pkt->length; i++)
    {
        printf("%02X ", pkt->data[i]);
    }
    printf("\r\n");

    // 패킷 타입별 상세 출력
    switch (pkt->type)
    {
        case BT_TYPE_DRIVE:  // 차량 구동 패킷
            printf("  -> Drive: L_Spd=%d, R_Spd=%d, L_Dir=%d, R_Dir=%d, Brake=%d\r\n",
                   pkt->data[0], pkt->data[1], pkt->data[2], pkt->data[3], pkt->data[4]);
            break;

        case BT_TYPE_TURRET:  // 터렛 제어 패킷 (수동)
        {
            int16_t x = (int16_t)((pkt->data[0] << 8) | pkt->data[1]);
            int16_t y = (int16_t)((pkt->data[2] << 8) | pkt->data[3]);
            printf("  -> Turret: X=%d, Y=%d\r\n", x, y);
            break;
        }

        case BT_TYPE_DESTRUCT:  // 자폭 명령
            printf("  -> DESTRUCT Command: 0x%02X\r\n", pkt->data[0]);
            break;

        case BT_TYPE_MODE:  // 모드 전환
            printf("  -> Mode Switch: 0x%02X\r\n", pkt->data[0]);
            break;

        case BT_TYPE_LASER:  // 레이저 ON/OFF
            printf("  -> Laser Toggle: 0x%02X\r\n", pkt->data[0]);
            break;

        default:
            printf("  -> Unknown packet type\r\n");
            break;
    }
}

/*============================================================================
 * 외부 호출용 래퍼 함수 (호환성 유지)
 *============================================================================*/
void BT_PrintPacket(void)
{
    BT_Packet_t pkt;
    __disable_irq();
    memcpy(&pkt, (void*)&bt_rx_packet, sizeof(BT_Packet_t));
    __enable_irq();
    BT_PrintPacketData(&pkt);
}

/*============================================================================
 * 수신된 패킷 처리 (main loop에서 호출)
 * ★ 핵심: flag 체크와 동시에 복사하여 Race Condition 완전 방지
 *============================================================================*/
void BT_ProcessPacket(void)
{
    BT_Packet_t local_pkt;
    uint8_t has_packet = 0;

    // ★ 인터럽트 비활성화 후 flag 체크 + 데이터 복사를 원자적으로 수행
    __disable_irq();
    if (bt_new_packet_flag)
    {
        bt_new_packet_flag = 0;
        memcpy(&local_pkt, (void*)&bt_rx_packet, sizeof(BT_Packet_t));
        has_packet = 1;
    }
    __enable_irq();

    // 인터럽트 활성화 후 안전하게 출력
    if (has_packet)
    {
        BT_PrintPacketData(&local_pkt);

        switch (local_pkt.type)
        {
        case BT_TYPE_DRIVE:
            if (local_pkt.length >= 5)
            {
                CAN_UpdateDriveCommand(local_pkt.data[0], local_pkt.data[1],
                                       local_pkt.data[2], local_pkt.data[3],
                                       local_pkt.data[4]);
                printf("[GW] Drive command updated\r\n");
            }
            break;

        case BT_TYPE_TURRET:
            if (local_pkt.length >= 4)
            {
                int16_t x = (int16_t)((local_pkt.data[0] << 8) | local_pkt.data[1]);
                int16_t y = (int16_t)((local_pkt.data[2] << 8) | local_pkt.data[3]);
                CAN_UpdateTurretManual(x, y);
                printf("[GW] Turret manual command X=%d Y=%d\r\n", x, y);
            }
            break;

        case BT_TYPE_DESTRUCT:
            if (local_pkt.length >= 1)
            {
                CAN_SendDestruct(local_pkt.data[0]);
                printf("[GW] Destruct command forwarded\r\n");
            }
            break;

        case BT_TYPE_MODE:
            if (local_pkt.length >= 1)
            {
                CAN_SendModeSwitch(local_pkt.data[0]);
                printf("[GW] Mode switch forwarded\r\n");
            }
            break;

        case BT_TYPE_LASER:
            if (local_pkt.length >= 1)
            {
                CAN_SendLaserToggle(local_pkt.data[0]);
                printf("[GW] Laser toggle forwarded\r\n");
            }
            break;

        default:
            break;
        }
    }
}

void BT_SendStatus(uint8_t state)
{
    uint8_t payload[1] = { state };
    BT_SendPacket(BT_TYPE_STATUS, 1, payload);
}

void BT_SendDrone(uint8_t state)
{
    uint8_t payload[1] = { state };
    BT_SendPacket(BT_TYPE_DRONE, 1, payload);
}

void BT_SendObstacle(uint8_t distance_cm, uint8_t direction)
{
    uint8_t payload[2] = { distance_cm, direction };
    BT_SendPacket(BT_TYPE_OBSTACLE, 2, payload);
}

/* USER CODE END 0 */

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USART2 init function */

void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}
/* USART3 init function */

void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

void HAL_UART_MspInit(UART_HandleTypeDef* uartHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspInit 0 */

  /* USER CODE END USART2_MspInit 0 */
    /* USART2 clock enable */
    __HAL_RCC_USART2_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USART2 interrupt Init */
    HAL_NVIC_SetPriority(USART2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspInit 1 */

  /* USER CODE END USART2_MspInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspInit 0 */

  /* USER CODE END USART3_MspInit 0 */
    /* USART3 clock enable */
    __HAL_RCC_USART3_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**USART3 GPIO Configuration
    PC5     ------> USART3_RX
    PB10     ------> USART3_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USART3 interrupt Init */
    HAL_NVIC_SetPriority(USART3_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspInit 1 */

  /* USER CODE END USART3_MspInit 1 */
  }
}

void HAL_UART_MspDeInit(UART_HandleTypeDef* uartHandle)
{

  if(uartHandle->Instance==USART2)
  {
  /* USER CODE BEGIN USART2_MspDeInit 0 */

  /* USER CODE END USART2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART2_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PA2     ------> USART2_TX
    PA3     ------> USART2_RX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_2|GPIO_PIN_3);

    /* USART2 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART2_IRQn);
  /* USER CODE BEGIN USART2_MspDeInit 1 */

  /* USER CODE END USART2_MspDeInit 1 */
  }
  else if(uartHandle->Instance==USART3)
  {
  /* USER CODE BEGIN USART3_MspDeInit 0 */

  /* USER CODE END USART3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART3_CLK_DISABLE();

    /**USART3 GPIO Configuration
    PC5     ------> USART3_RX
    PB10     ------> USART3_TX
    */
    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_5);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_10);

    /* USART3 interrupt Deinit */
    HAL_NVIC_DisableIRQ(USART3_IRQn);
  /* USER CODE BEGIN USART3_MspDeInit 1 */

  /* USER CODE END USART3_MspDeInit 1 */
  }
}

/* USER CODE END 1 */
